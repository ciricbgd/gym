<div class="container cards_home">
    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card_header <?php echo e($card->color); ?>-gradient-color">
                <h3><?php echo e($card->name); ?></h3>
            </div>
            <div class="card_name">$<?php echo e($card->price); ?></div>
            <div class="card-body">
                <table class="table table-hover table-sm">
                    <?php echo $card->perks; ?>

                </table>
                <a href="#" class="btn btn-primary">Purchase</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>