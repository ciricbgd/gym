
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/lightslider.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/lightbox.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="page_home" class="page">
        <?php echo $__env->make('components.cards', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <?php if(session()->has('user')): ?>
        <?php if(!$surveys->isEmpty()): ?>
            <div id="page_survey" class="page">
                <?php echo $__env->make('components.survey', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    <div id="page_articles" class="page">
        <?php echo $__env->make('components.articles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
    <div id="page_showcase" class="page">
        <?php echo $__env->make('components.showcase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/lightslider.min.js"></script>
    <script src="<?php echo e(url('/')); ?>/js/lightbox.min.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.shell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>