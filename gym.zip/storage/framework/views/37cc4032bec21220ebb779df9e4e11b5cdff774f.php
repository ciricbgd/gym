
<?php $__env->startSection('admin_page'); ?>
    <table class="table table-hover table-responsive">
            <thead>
                <tr>
                    <th>Firstname</th>
                    <th>Lastname</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Birth date</th>
                    <th>Phone number</th>
                    <th>Role</th>
                    <?php if(session()->get('user')[0]->role_id>=3): ?><th>Change Role</th><?php endif; ?>
                    <th>edit</th>
                    <th>delete</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr data-uid="<?php echo e($user->id); ?>">
                    <input type="hidden" name="_token" class="token" value="<?php echo e(csrf_token()); ?>" data-uid="<?php echo e($user->id); ?>">
                    <td><?php echo e($user->firstname); ?></td>
                    <td><?php echo e($user->lastname); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->date); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <?php if(session()->get('user')[0]->role_id>=3): ?>
                        <td>
                            <select class="form-control selectRole" data-uid="<?php echo e($user->id); ?>">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->role!=$role->role AND $role->role!='owner'): ?>
                                        <option class="form-control" value="<?php echo e($role->id); ?>"><?php echo e($role->role); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </td>
                    <?php endif; ?>
                    <td><button class="btn btn-secondary btnEditUser" data-uid="<?php echo e($user->id); ?>">Edit user</button></td>
                    <td><button class="btn btn-danger btnDeleteUser" data-uid="<?php echo e($user->id); ?>">Delete user</button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>