<div class="container cards_home">
    <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="card_header <?php echo e($card->color); ?>-gradient-color">
                <h3><?php echo e($card->name); ?></h3>
            </div>
            <div class="card_name">$<?php echo e($card->price); ?></div>
            <div class="card-body">
                <table class="table table-hover table-sm">
                    <?php echo $card->perks; ?>

                </table>
                <?php if(session()->has('user')): ?>
                    <form action="<?php echo e(route('purchaseMembership')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php if(session()->has('user')): ?>
                        <?php endif; ?>
                        <input type="hidden" name="user_id" value="<?php echo e(session()->get('user')[0]->id); ?>">
                        <input type="hidden" name="membership_id" value="<?php echo e($card->id); ?>">
                        <input type="submit" class="form-control btn btn-primary" value="Purchase">
                    </form>
                <?php else: ?>
                    <p class="text-info text-justify">Please log in to purchase.</p>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>