 <?php $__env->startSection('content'); ?>
<div id="register_page">
</div>
<form action="<?php echo e(route('register_send')); ?>" method="POST" enctype="multipart/form-data" class="container rounded" id="register_form">
    <?php echo e(csrf_field()); ?>

    <table>
        <tr>
            <td><input type="text" class="form-control" name="tbFirstName" id="tbFirstName" placeholder="Firstname"></td>
            <td><input type="text" class="form-control" name="tbLastName" id="tbLastName" placeholder="Lastname"></td>
        </tr>
        <tr>
            <td><input type="text" class="form-control" name="tbUsername" id="tbUsername" placeholder="Username"></td>
            <td><input type="password" class="form-control" name="tbPassword" id="tbPassword" placeholder="Password"></td>
        </tr>
        <tr>
            <td colspan="2">
                <p class="text-muted">Birth date (optional):</p>
                <div class="dateholder">
                    <select class="form-control dateselector" id="dateDay" name="dateDay">
                        <option value="">Day</option>
                        <?php for($i=1; $i<=31; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select class="form-control dateselector" id="dateMonth" name="dateMonth">
                        <option value="">Month</option>
                        <?php for($i=1; $i<=12; $i++): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <select class="form-control dateselector" id="dateYear" name="dateYear">
                        <option value="">Year</option>
                        <?php for($i=date('Y'); $i>=date('Y')-100; $i--): ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                </div>
            </td>
        </tr>
        <tr>
            <td colspan="2"><input type="email" class="form-control" name="tbEmail" id="tbEmail" placeholder="Email"></td>
        </tr>
        <tr>
            <td colspan="2"><input type="tel" class="form-control" name="tbPhone" id="tbPhone" placeholder="Phone number (optional)"></td>
        </tr>
        <tr class="registration_row">
            <td colspan="2" class="registerholder"><button type="submit" class="btn btn-primary">Register</button></td>
        </tr>
    </table>
</form>
<?php if($errors->any() OR !empty($alerts)): ?>
<div class="container form_alerts">
    <div class="alert alert-danger">
        <ul>
            <?php if(!empty($alerts)): ?> <?php $__currentLoopData = $alerts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($alert); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?> <?php if($errors->any()): ?> <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
        </ul>
    </div>
</div>
<?php endif; ?> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.shell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>