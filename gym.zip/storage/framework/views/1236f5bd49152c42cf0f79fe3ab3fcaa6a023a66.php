<?php if(!empty($surveys)): ?>
    <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card survey_card">
            <form action="<?php echo e(route('survey.submit')); ?>" method="POST" class="form form-horizontal survey_form" data-survey-id="<?php echo e($survey->id); ?>">
                <?php echo e(csrf_field()); ?>

                <ul class="survey">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($question->survey_id==$survey->id): ?>
                            <li>
                                <h6>Question #<?php echo e($loop->iteration); ?></h6>
                                <h4><?php echo e($question->name); ?></h4>
                                <div class="form-check">
                                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($answer->question_id==$question->id): ?>
                                            <input class="form-check-input" type="<?php echo e($question->answer_format); ?>"name="<?php echo e($question->id); ?>" data-survey-id="<?php echo e($survey->id); ?>" data-question-id="<?php echo e($question->id); ?>" value="<?php echo e($answer->id); ?>">
                                            <label class="form-check-label"><?php echo e($answer->name); ?></label>
                                            <br>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <h4 style="width:100%;text-align:center;">Thank you for your time</h4>
                            <br><br>
                            <button type="button" class="btn btn-outline-primary survey_submit" data-survey-id="<?php echo e($survey->id); ?>">Submit</button>
                        </li>
                </ul>
            </form>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>