<?php $__env->startSection('content'); ?>
    <div id="signle_article" class="page">
        <article>
            <h3><?php echo e($article[0]->header); ?></h3>
            <img src="<?php echo e(url('/img/articles')); ?>/<?php echo e($article[0]->img); ?>" alt="<?php echo e($article[0]->alt); ?>">
            <p><?php echo e($article[0]->text); ?></p>
        </article>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.shell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>