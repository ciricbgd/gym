<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/css/admin_panel.css">
<?php echo $__env->yieldSection(); ?>
<?php $__env->startSection('content'); ?>
        <?php echo $__env->make('components.admin_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="admin_right">
            <?php echo $__env->yieldContent('admin_page'); ?>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('/')); ?>/js/admin_panel.js"></script>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('layouts.shell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>