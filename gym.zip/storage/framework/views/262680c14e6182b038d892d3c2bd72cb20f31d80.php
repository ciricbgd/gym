
<?php $__env->startSection('admin_page'); ?>
    <input type="hidden" name="_token" id="token" value="<?php echo e(csrf_token()); ?>">
    <table class="table table-hover table-responsive">
        <thead>
            <th>Title</th>
            <th>img</th>
            <th>alt</th>
            <th>delte</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $showcase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($img->title); ?></td>
                    <td><?php echo e($img->img); ?></td>
                    <td><?php echo e($img->alt); ?></td>
                    <td><button class="btn btn-danger deleteShowcase" data-id="<?php echo e($img->id); ?>">Delete showcase</button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <form action="<?php echo e(url('/')); ?>/admin/insertShowcase" enctype="multipart/form-data" method="POST" style="max-width:320px;">
        <?php echo e(csrf_field()); ?>

        <input type="text" class="form-control" name="title" placeholder="New showcase title">
        <br>
        <input type="file" name="image" class="form-control">
        <br>
        <input type="text" class="form-control" name="alt" placeholder="image alt">
        <br>
        <input type="submit" class="btn btn-primary mb-2">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>