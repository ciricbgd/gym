
<?php $__env->startSection('admin_page'); ?>
    <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="token">
    <table class="table table-hover">
        <thead>
            <th>Title</th>
            <th>Image</th>
            <th>alt</th>
            <th>text</th>
            <th>delete</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($article->header); ?></td>
                    <td><?php echo e($article->img); ?></td>
                    <td><?php echo e($article->alt); ?></td>
                    <td style="max-width:100px;white-space: nowrap; overflow: hidden;text-overflow: ellipsis; "><?php echo e($article->text); ?></td>
                    <td><button class="btn btn-danger deleteArticle" data-id="<?php echo e($article->id); ?>">Delete article</button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

        <form action="<?php echo e(route('submitArticle')); ?>" method="POST" id="articleForm" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="header" class="form-control" placeholder="New article title">
            <br>
            <input type="file" name="image" class="form-control">
            <br>
            <input type="text" name="alt" class="form-control" placeholder="Alt for image">
            <br>
            <textarea name="text" class="form-control" placeholder="Text"></textarea>
            <br>
            <input type="submit" class="btn btn-primary mb-2">
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>