@extends('layouts.shell')
@section('content')
    <div id="page_autor">
        @include('components.autor')
    </div>
@endsection