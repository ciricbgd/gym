<div id="admin_left">
    <div id="admin_left_holder">
        <table class="table table-hover table-dark">
            <tr><td><a href="{{route('admin.manage_users')}}">Manage users</a></td></tr>
            <tr><td><a href="{{route('admin.memberships')}}">Memberships</a></td></tr>
            <tr><td><a href="{{route('admin.surveys')}}">Surveys</a></td></tr>
            <tr><td><a href="{{route('admin.articles')}}">Articles</a></td></tr>
            <tr><td><a href="{{route('admin.showcase')}}">Showcase</a></td></tr>
        </table>
    </div>
</div>