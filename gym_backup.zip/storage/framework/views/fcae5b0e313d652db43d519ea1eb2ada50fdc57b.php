<?php $__env->startSection('admin_page'); ?>
    <table class="table table-hover">
        <?php $__currentLoopData = $memberships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><input type="text" name="tbName" class="form-control membershipName" value="<?php echo e($membership->name); ?>" size="1" data-mid="<?php echo e($membership->id); ?>"></td>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" class="token" data-mid="<?php echo e($membership->id); ?>">
                <td>
                    <select name="selectColor" class="form-control membershipColor" data-mid="<?php echo e($membership->id); ?>">
                        <option value="blue" <?php if($membership->color=='blue'): ?><?php echo e('selected'); ?><?php endif; ?>>blue</option>
                        <option value="green" <?php if($membership->color=='green'): ?><?php echo e('selected'); ?><?php endif; ?>>green</option>
                        <option value="red" <?php if($membership->color=='red'): ?><?php echo e('selected'); ?> <?php endif; ?>>red</option>
                    </select>
                </td>
                <td>
                        <input type="text" class="form-control membershipPrice" name="tbPrice" value="<?php echo e($membership->price); ?>" size="1" maxlength="6" data-mid="<?php echo e($membership->id); ?>">
                    </div>
                </td>
                <td><button class="btn btn-secondary btnEditMembership" data-mid="<?php echo e($membership->id); ?>">Edit membership</button></td>
                <td><button class="btn btn-danger btnDeleteMembership" data-mid="<?php echo e($membership->id); ?>">Delete membership</button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <form action="<?php echo e(route('insertMembership')); ?>" method="POST" style="max-width:320px;">
        <?php echo e(csrf_field()); ?>

        <input type="text" name="name" class="form-control" placeholder="New membership name">
        <br>
        <input type="text" name="color" class="form-control" placeholder="Color">
        <br>
        <input type="text" name="price" class="form-control" placeholder="Price in $">
        <br>
        <textarea name="perks" class="form-control" placeholder="Preks&#10Seperate them with \ slash sign"></textarea>
        <br>
        <input type="submit" class="btn btn-primary mb-2">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>