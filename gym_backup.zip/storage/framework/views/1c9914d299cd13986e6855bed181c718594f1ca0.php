<section id="articles">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article>
        <h3><?php echo e($article->header); ?></h3>
        <img src="<?php echo e(url('/img/articles')); ?>/<?php echo e($article->img); ?>" alt="<?php echo e($article->alt); ?>">
        <p><?php echo e($article->text); ?></p>
        <a class="btn btn-primary" href="<?php echo e(url('/article')); ?>/<?php echo e($article->id); ?>">Read more</a>
    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<div id="articlePager">
    <button class="btn btn-primary float-left articleBtn articleBtnLeft"><</button>
    <p class="text-white" id="articlePageNumber">page:1</p>
    <button class="btn btn-primary float-right articleBtn articleBtnRight">></button>
</div>
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="pagerToken">
