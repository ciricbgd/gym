
<?php $__env->startSection('content'); ?>
    <div id="page_autor">
        <?php echo $__env->make('components.autor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.shell', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>