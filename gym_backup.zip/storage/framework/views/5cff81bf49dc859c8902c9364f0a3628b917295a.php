
<?php $__env->startSection('admin_page'); ?>
    <input type="hidden" value="<?php echo e(csrf_token()); ?>" id="token">
    <table class="table table-hover">
        <thead>
            <th>Title</th>
            <th>Image</th>
            <th>alt</th>
            <th>text</th>
            <th>edit</th>
            <th>delete</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="text" class="articleHeader form-control" value="<?php echo e($article->header); ?>" data-id="<?php echo e($article->id); ?>"></td>
                    <td><img src="<?php echo e(url('/')); ?>/img/articles/<?php echo e($article->img); ?>" alt="<?php echo e($article->alt); ?>" style="width:100px;height:50px;object-fit:cover;"></td>
                    <td><input type="text" class="articleAlt form-control" value="<?php echo e($article->alt); ?>" data-id="<?php echo e($article->id); ?>"></td>
                    <td><textarea cols="50" rows="3" class="articleText form-control" data-id="<?php echo e($article->id); ?>"><?php echo e($article->text); ?></textarea></td>
                    <td><button class="btn btn-secondary btnEditArticle" data-id="<?php echo e($article->id); ?>">Edit showcase</button></td>
                    <td><button class="btn btn-danger deleteArticle" data-id="<?php echo e($article->id); ?>">Delete article</button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

        <form action="<?php echo e(route('submitArticle')); ?>" method="POST" id="articleForm" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="header" class="form-control" placeholder="New article title">
            <br>
            <input type="file" name="image" class="form-control">
            <br>
            <input type="text" name="alt" class="form-control" placeholder="Alt for image">
            <br>
            <textarea name="text" class="form-control" placeholder="Text"></textarea>
            <br>
            <input type="submit" class="btn btn-primary mb-2">
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>