<h1>The gym showcase</h1>
<h2>Our best moments</h2>
<?php $__currentLoopData = $showcase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/')); ?>/img/showcase/<?php echo e($img->img); ?>" data-lightbox="gym" data-title="<?php echo e($img->title); ?>"><img src="<?php echo e(url('/')); ?>/img/showcase/<?php echo e($img->img); ?>" alt="<?php echo e($img->alt); ?>"></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>