
<?php $__env->startSection('admin_page'); ?>
    <table class="table table-hover">
        <thead>
            <tr>
                <th><?php $__currentLoopData = $survey_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($name->name); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $survey_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($question->name); ?></td>
                        <?php $__currentLoopData = $survey_answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($answer->question_id==$question->id): ?>
                                <td>
                                    <?php echo e($answer->name); ?>:
                                    <?php $i=0;?>
                                    <?php $__currentLoopData = $survey_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($result->answer_id == $answer->id): ?>
                                            <?php $i++;?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $i;?>
                                </td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>