<?php $__env->startSection('admin_page'); ?>
    <?php echo e($survey_name); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>