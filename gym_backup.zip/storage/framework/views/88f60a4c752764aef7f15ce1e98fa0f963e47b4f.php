<div id="admin_left">
    <div id="admin_left_holder">
        <table class="table table-hover table-dark">
            <tr><td><a href="<?php echo e(route('admin.manage_users')); ?>">Manage users</a></td></tr>
            <tr><td><a href="<?php echo e(route('admin.memberships')); ?>">Memberships</a></td></tr>
            <tr><td><a href="<?php echo e(route('admin.surveys')); ?>">Surveys</a></td></tr>
            <tr><td><a href="<?php echo e(route('admin.articles')); ?>">Articles</a></td></tr>
            <tr><td><a href="<?php echo e(route('admin.showcase')); ?>">Showcase</a></td></tr>
        </table>
    </div>
</div>