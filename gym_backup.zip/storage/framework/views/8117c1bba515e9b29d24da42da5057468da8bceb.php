<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="<?php echo e(route($home[0]->route)); ?>"><?php echo e($home[0]->name); ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <?php if(Request::route()->getName()=='home'): ?>
                <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item active">
                        <a class="nav-link" href="<?php echo e($n->route); ?>"><?php echo e($n->name); ?><span class="sr-only"></span></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
                <?php if($errors->any()): ?>
                    <li class="text-danger"><?php echo e($errors->first()); ?></li>
                <?php endif; ?>
        </ul>
        <?php if(session()->has('user')): ?>
            <?php if(session()->get('user')[0]->role_id > 0): ?>
                <a href="<?php echo e(route($home[1]->route)); ?>" class="nav_btn"><button class="btn btn-outline-warning my-2 my-sm-0"><?php echo e($home[1]->name); ?></button></a>
            <?php endif; ?>
        <?php endif; ?>
        <?php if(session()->has('user')): ?>
            <a href="<?php echo e(route($home[2]->route)); ?>" class="nav_btn"><button class="btn btn-outline-warning my-2 my-sm-0"><?php echo e(session()->get('user')[0]->username); ?> | <?php echo e($home[2]->name); ?></button></a>
        <?php endif; ?>
        <?php if(!session()->has('user')): ?>
            <a href="<?php echo e(route('register')); ?>" class="nav_btn"><button class="btn btn-outline-warning my-2 my-sm-0">Register</button></a>
            <div class="nav_btn login_toggle">
                <button class="btn btn-outline-warning my-2 my-sm-0">Login</button>
            </div>
            <form action="<?php echo e(route('login')); ?>" method="POST" id="login_form" style="display:none">
                <?php echo e(csrf_field()); ?>

                <input type="text" class="form-control" name="tbUsername" placeholder="username">
                <input type="password" class="form-control" name="tbPassword" placeholder="password">
                <input type="submit" class="form-control clickable" value="Login">
            </form>
    </div>
        <?php endif; ?>
</nav>
