<div class="workouts">
    <p>Workouts left: <?php echo e($workouts[0]->workouts); ?></p>
    <?php if(session()->has('user')): ?>
        <form action="<?php echo e(route('workout')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="user_id" value="<?php echo e(session()->get('user')[0]->id); ?>">
            <input type="submit" class="form-control btn btn-primary" value="Check-in (workout)">
        </form>
    <?php endif; ?>
</div>